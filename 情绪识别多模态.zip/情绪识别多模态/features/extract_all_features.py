"""
多模态特征提取统一入口
支持文本、音频、视频三种模态的特征提取
"""

import os
import sys
import time
import argparse
from datetime import datetime

def run_text_extraction():
    """运行文本特征提取"""
    print("=" * 60)
    print("开始文本特征提取...")
    print("=" * 60)
    
    try:
        # 导入并运行文本特征提取
        import feature_exrt
        print("✓ 文本特征提取完成")
        return True
    except Exception as e:
        print(f"✗ 文本特征提取失败: {e}")
        return False

def run_audio_extraction():
    """运行音频特征提取"""
    print("=" * 60)
    print("开始音频特征提取...")
    print("=" * 60)
    
    try:
        # 导入并运行音频特征提取
        import audio_feature_extract
        print("✓ 音频特征提取完成")
        return True
    except Exception as e:
        print(f"✗ 音频特征提取失败: {e}")
        return False

def run_video_extraction():
    """运行视频特征提取"""
    print("=" * 60)
    print("开始视频特征提取...")
    print("=" * 60)
    
    try:
        # 导入并运行视频特征提取
        import video_feature_extract
        print("✓ 视频特征提取完成")
        return True
    except Exception as e:
        print(f"✗ 视频特征提取失败: {e}")
        return False

def check_dependencies():
    """检查依赖库安装情况"""
    print("检查依赖库...")
    
    dependencies = {
        'numpy': 'numpy',
        'pandas': 'pandas', 
        'jieba': 'jieba',
        'pickle': 'pickle',
        'librosa': 'librosa',
        'cv2': 'opencv-python',
        'dlib': 'dlib'
    }
    
    missing_deps = []
    available_deps = []
    
    for module, package in dependencies.items():
        try:
            __import__(module)
            available_deps.append(f"✓ {package}")
        except ImportError:
            missing_deps.append(f"✗ {package}")
    
    print("\n依赖库状态:")
    for dep in available_deps:
        print(dep)
    for dep in missing_deps:
        print(dep)
    
    if missing_deps:
        print(f"\n警告: {len(missing_deps)} 个依赖库未安装，将使用模拟数据")
    
    return len(missing_deps) == 0

def main():
    parser = argparse.ArgumentParser(description='多模态特征提取工具')
    parser.add_argument('--modality', type=str, choices=['text', 'audio', 'video', 'all'], 
                       default='all', help='选择要提取的模态特征')
    parser.add_argument('--check-deps', action='store_true', 
                       help='仅检查依赖库，不运行特征提取')
    
    args = parser.parse_args()
    
    print("多模态情感分析特征提取工具")
    print(f"运行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 检查依赖
    if args.check_deps:
        check_dependencies()
        return
    
    # 切换到features目录
    original_dir = os.getcwd()
    features_dir = os.path.join(os.path.dirname(__file__))
    if features_dir:
        os.chdir(features_dir)
    
    try:
        start_time = time.time()
        success_count = 0
        total_count = 0
        
        # 根据参数选择运行的模态
        if args.modality in ['text', 'all']:
            total_count += 1
            if run_text_extraction():
                success_count += 1
            print()
        
        if args.modality in ['audio', 'all']:
            total_count += 1
            if run_audio_extraction():
                success_count += 1
            print()
        
        if args.modality in ['video', 'all']:
            total_count += 1
            if run_video_extraction():
                success_count += 1
            print()
        
        # 总结
        end_time = time.time()
        duration = end_time - start_time
        
        print("=" * 60)
        print("特征提取完成总结:")
        print(f"成功: {success_count}/{total_count}")
        print(f"耗时: {duration:.2f} 秒")
        
        if success_count == total_count:
            print("✓ 所有特征提取任务成功完成")
        else:
            print("⚠ 部分特征提取任务失败，请检查错误信息")
        
        # 列出生成的特征文件
        print("\n生成的特征文件:")
        feature_files = [
            'text_ml_features.pkl',
            'audio_ml_features.pkl', 
            'video_ml_features.pkl'
        ]
        
        for file in feature_files:
            if os.path.exists(file):
                size = os.path.getsize(file) / 1024  # KB
                print(f"✓ {file} ({size:.1f} KB)")
            else:
                print(f"✗ {file} (未生成)")
        
        print("=" * 60)
        
    finally:
        # 恢复原始工作目录
        os.chdir(original_dir)

if __name__ == "__main__":
    main() 