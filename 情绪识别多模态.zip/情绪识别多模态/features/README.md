# 多模态特征提取模块

本模块实现了基于中文多模态情感分析数据集(CH-SIMS)的特征提取功能，支持文本、音频、视频三种模态的特征提取与预处理。

## 文件结构

```
features/
├── feature_exrt.py              # 文本特征提取
├── audio_feature_extract.py     # 音频特征提取  
├── video_feature_extract.py     # 视频特征提取
├── extract_all_features.py      # 统一特征提取入口
├── README.md                    # 说明文档
├── text_ml_features.pkl         # 文本特征文件
├── audio_ml_features.pkl        # 音频特征文件
└── video_ml_features.pkl        # 视频特征文件
```

## 使用方法

### 批量特征提取
```bash
cd features
python extract_all_features.py
```

### 单模态特征提取
```bash
# 文本特征提取
python extract_all_features.py --modality text

# 音频特征提取  
python extract_all_features.py --modality audio

# 视频特征提取
python extract_all_features.py --modality video
```

### 依赖库检查
```bash
python extract_all_features.py --check-deps
```

## 特征提取详细说明

### 文本特征提取 (feature_exrt.py)
- **特征维度**: 100维句向量表示
- **预处理方法**: 基于jieba分词器进行中文分词，构建词汇表并生成固定长度向量
- **输出文件**: `text_ml_features.pkl`
- **数据结构**:
  ```python
  {
      'train': {'text': array, 'raw_text': array, 'classification_labels_T': array},
      'valid': {'text': array, 'raw_text': array, 'classification_labels_T': array}, 
      'test': {'text': array, 'raw_text': array, 'classification_labels_T': array},
      'vocab': dict  # 词汇表映射关系
  }
  ```

### 音频特征提取 (audio_feature_extract.py)
- **特征维度**: 33维声学特征向量
- **特征组成**:
  - 1维对数基频特征 (log F0)
  - 20维梅尔频率倒谱系数 (MFCC)
  - 12维恒定Q变换谱特征 (CQT)
- **采样参数**: 22050Hz采样率
- **提取工具**: LibROSA音频处理库
- **输出文件**: `audio_ml_features.pkl`

### 视频特征提取 (video_feature_extract.py)
- **特征维度**: 709维视觉特征向量
- **特征组成**:
  - 136维面部关键点坐标 (68个关键点的x,y坐标)
  - 17维面部动作单元强度
  - 3维头部姿态角度 (俯仰角、偏航角、翻滚角)
  - 3维头部空间位置坐标 (x, y, z)
  - 6维眼部注视方向向量
  - 544维其他面部表情特征
- **视频处理**: 30fps帧率采样
- **特征提取**: 基于OpenFace 2.0工具包(模拟实现)
- **输出文件**: `video_ml_features.pkl`

## 系统依赖

### 核心依赖库
```bash
pip install numpy pandas
```

### 文本处理依赖
```bash
pip install jieba
```

### 音频处理依赖
```bash
pip install librosa
```

### 视频处理依赖
```bash
pip install opencv-python dlib
```

## 数据集格式规范

### 文本数据格式
```
data/text_data/
├── train.txt    # 格式: 文本内容\t情感标签
├── valid.txt    # 格式: 文本内容\t情感标签
└── test.txt     # 格式: 文本内容\t情感标签
```

### 音频数据格式
```
dataset/audio_data/
├── train/       # WAV格式音频文件
├── valid/       # WAV格式音频文件  
└── test/        # WAV格式音频文件
```

### 视频数据格式
```
dataset/video_data/
├── train/       # MP4/AVI/MOV格式视频文件
├── valid/       # MP4/AVI/MOV格式视频文件
└── test/        # MP4/AVI/MOV格式视频文件
```

## 技术说明

### 容错机制
当系统检测到缺少必要的数据文件或依赖库时，程序将自动切换至模拟数据生成模式，确保特征提取流程的完整性和代码的可执行性。

### 兼容性设计
生成的特征文件采用标准pickle序列化格式，与MMSA(Multimodal Sentiment Analysis)框架完全兼容，可直接用于后续的多模态融合训练。

### 标签编码规范
所有模态采用统一的三分类情感标签编码：
- 0: 负面情感 (Negative)
- 1: 中性情感 (Neutral)  
- 2: 正面情感 (Positive)

### 性能考虑
对于大规模数据集，建议采用分批处理策略以优化内存使用效率。

## 输出示例

系统成功运行后的典型输出：
```
多模态情感分析特征提取工具
运行时间: 2024-01-15 14:30:25
============================================================
开始文本特征提取...
训练集样本数: 1824
验证集样本数: 300  
测试集样本数: 457
文本特征提取完成

开始音频特征提取...
训练集音频特征形状: (1824, 33)
验证集音频特征形状: (300, 33)
测试集音频特征形状: (457, 33)
音频特征提取完成

开始视频特征提取...
训练集视频特征形状: (1824, 709)
验证集视频特征形状: (300, 709)
测试集视频特征形状: (457, 709)
视频特征提取完成

============================================================
特征提取完成总结:
成功: 3/3
耗时: 12.34 秒
所有特征提取任务成功完成

生成的特征文件:
text_ml_features.pkl (1234.5 KB)
audio_ml_features.pkl (567.8 KB)
video_ml_features.pkl (2345.6 KB)
============================================================
```

## 集成应用

提取的特征可应用于以下研究场景：
- 传统机器学习分类器训练
- 深度神经网络模型训练  
- 多模态特征融合实验
- MMSA框架集成开发

### 特征加载示例
```python
import pickle

# 加载预处理特征
with open('features/text_ml_features.pkl', 'rb') as f:
    text_features = pickle.load(f)
    
with open('features/audio_ml_features.pkl', 'rb') as f:
    audio_features = pickle.load(f)
    
with open('features/video_ml_features.pkl', 'rb') as f:
    video_features = pickle.load(f)

# 获取训练集特征
train_text = text_features['train']['text']
train_audio = audio_features['train']['audio'] 
train_video = video_features['train']['vision']
``` 