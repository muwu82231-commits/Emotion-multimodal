import pandas as pd
import numpy as np
import jieba
import pickle
from collections import Counter
import os

# 创建保存目录
os.makedirs("./features", exist_ok=True)

# Step 1: 从txt文件读取数据
print("读取数据...")
def read_data_from_txt(file_path):
    texts = []
    labels = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():  # 忽略空行
                parts = line.strip().split('\t')
                if len(parts) == 2:
                    text, label = parts
                    texts.append(text)
                    labels.append(int(label))
    return texts, labels

# 读取三个数据集
train_texts, train_labels = read_data_from_txt('./data/text_data/train.txt')
valid_texts, valid_labels = read_data_from_txt('./data/text_data/valid.txt')
test_texts, test_labels = read_data_from_txt('./data/text_data/test.txt')

print(f"训练集样本数: {len(train_texts)}")
print(f"验证集样本数: {len(valid_texts)}")
print(f"测试集样本数: {len(test_texts)}")

# Step 2: 使用jieba进行分词
print("正在进行分词...")
def tokenize_text(text):
    return list(jieba.cut(text))

train_tokens = [tokenize_text(text) for text in train_texts]
valid_tokens = [tokenize_text(text) for text in valid_texts]
test_tokens = [tokenize_text(text) for text in test_texts]

# Step 3: 构建词表 (仅使用训练集)
print("构建词表...")
all_words = [word for doc in train_tokens for word in doc]
word_counts = Counter(all_words)

# 选择频率最高的词构建词表 (保留一些额外的位置，如未知词等)
vocab_size = 98  # 保留2个位置给特殊标记
word_list = [word for word, count in word_counts.most_common(vocab_size)]
vocab = {"<PAD>": 0, "<UNK>": 1}  # 特殊标记
vocab.update({word: idx + 2 for idx, word in enumerate(word_list)})

print(f"词表大小: {len(vocab)}")

# Step 4: 将文本转换为句向量 (固定长度100)
print("生成句向量...")
def text_to_vector(tokens, max_len=100):
    vector = np.zeros(max_len, dtype=np.int32)
    for i, token in enumerate(tokens):
        if i >= max_len:
            break
        vector[i] = vocab.get(token, vocab["<UNK>"])  # 使用<UNK>标记未知词
    return vector

# 生成句向量
train_vectors = np.array([text_to_vector(tokens) for tokens in train_tokens])
valid_vectors = np.array([text_to_vector(tokens) for tokens in valid_tokens])
test_vectors = np.array([text_to_vector(tokens) for tokens in test_tokens])

train_labels = np.array(train_labels)
valid_labels = np.array(valid_labels)
test_labels = np.array(test_labels)

print(f"训练集句向量形状: {train_vectors.shape}")
print(f"验证集句向量形状: {valid_vectors.shape}")
print(f"测试集句向量形状: {test_vectors.shape}")

# Step 5: 创建所需的特征字典
text_features = {
    'train': {
        'text': train_vectors,
        'raw_text': np.array(train_texts),
        'classification_labels_T': train_labels
    },
    'valid': {
        'text': valid_vectors,
        'raw_text': np.array(valid_texts),
        'classification_labels_T': valid_labels
    },
    'test': {
        'text': test_vectors,
        'raw_text': np.array(test_texts),
        'classification_labels_T': test_labels
    },
    'vocab': vocab  # 保存词表以便后续使用
}

# 保存特征和词表到文件
with open('./features/text_ml_features.pkl', 'wb') as f:
    pickle.dump(text_features, f)

print("文本特征提取完成，保存到 ./features/text_ml_features.pkl")

# 展示一些示例以验证结果
print("\n示例句向量:")
for i in range(min(3, len(train_texts))):
    original_text = train_texts[i]
    vector = train_vectors[i]
    tokens = train_tokens[i]
    
    print(f"原始文本: {original_text}")
    print(f"分词结果: {tokens}")
    print(f"句向量 (前10个元素): {vector[:10]}")
    print(f"向量中非零元素数量: {np.count_nonzero(vector)}")
    
    # 将数字标签映射回文本标签
    label_map_reverse = {0: "Negative", 1: "Neutral", 2: "Positive"}
    print(f"标签: {train_labels[i]} ({label_map_reverse[train_labels[i]]})")
    print("-" * 50)