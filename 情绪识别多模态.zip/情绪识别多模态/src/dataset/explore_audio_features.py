import torch
import pickle
import numpy as np

# 加载数据集
path = '/home/egdon/workspace/Multimodal-emotion-main/features/unaligned_39.pkl'
with open(path, 'rb') as f:
    dataset = pickle.load(f)

# 函数：将音频特征和标签保存为NPY文件
def save_audio_and_labels(feature_path, label_path, audio_features, labels):
    # 保存音频特征
    np.save(feature_path, np.array(audio_features))
    # 保存标签
    np.save(label_path, np.array(labels))
    print(f"Saved features to {feature_path} with shape {np.array(audio_features).shape}")
    print(f"Saved labels to {label_path} with shape {np.array(labels).shape}")

# 函数：将音频特征和标签写入文本文件 (如果需要文本格式)
def write_audio_info_to_txt(file_path, audio_lengths, labels):
    with open(file_path, 'w', encoding='utf-8') as file:
        for length, label in zip(audio_lengths, labels):
            line = str(length) + '\t' + str(int(label)) + '\n'
            file.write(line)
    print(f"Saved audio info to {file_path}")

# 创建目录结构（如果需要）
import os
os.makedirs('./data/audio_data', exist_ok=True)

# 提取并保存训练集
print("处理训练集...")
train_audio = dataset['train']['audio']
train_labels = dataset['train']['classification_labels_A']
train_lengths = dataset['train']['audio_lengths']
# 检查数据
print(f"训练集音频数据形状: {np.array(train_audio).shape}")
print(f"训练集音频长度信息: 最小={min(train_lengths)}, 最大={max(train_lengths)}, 平均={sum(train_lengths)/len(train_lengths)}")
# 保存数据
save_audio_and_labels('./data/audio_data/train_audio.npy', './data/audio_data/train_labels.npy', train_audio, train_labels)
write_audio_info_to_txt('./data/audio_data/train_info.txt', train_lengths, train_labels)

# 提取并保存验证集
print("\n处理验证集...")
valid_audio = dataset['valid']['audio']
valid_labels = dataset['valid']['classification_labels_A']
valid_lengths = dataset['valid']['audio_lengths']
# 检查数据
print(f"验证集音频数据形状: {np.array(valid_audio).shape}")
print(f"验证集音频长度信息: 最小={min(valid_lengths)}, 最大={max(valid_lengths)}, 平均={sum(valid_lengths)/len(valid_lengths)}")
# 保存数据
save_audio_and_labels('./data/audio_data/valid_audio.npy', './data/audio_data/valid_labels.npy', valid_audio, valid_labels)
write_audio_info_to_txt('./data/audio_data/valid_info.txt', valid_lengths, valid_labels)

# 提取并保存测试集
print("\n处理测试集...")
test_audio = dataset['test']['audio']
test_labels = dataset['test']['classification_labels_A']
test_lengths = dataset['test']['audio_lengths']
# 检查数据
print(f"测试集音频数据形状: {np.array(test_audio).shape}")
print(f"测试集音频长度信息: 最小={min(test_lengths)}, 最大={max(test_lengths)}, 平均={sum(test_lengths)/len(test_lengths)}")
# 保存数据
save_audio_and_labels('./data/audio_data/test_audio.npy', './data/audio_data/test_labels.npy', test_audio, test_labels)
write_audio_info_to_txt('./data/audio_data/test_info.txt', test_lengths, test_labels)

# 打印一些统计信息
print("\n数据集统计信息:")
print(f"训练集: {len(train_audio)} 个样本")
print(f"验证集: {len(valid_audio)} 个样本")
print(f"测试集: {len(test_audio)} 个样本")

# 统计标签分布
from collections import Counter
print("\n标签分布:")
print(f"训练集标签分布: {Counter(train_labels.tolist() if isinstance(train_labels, np.ndarray) else train_labels)}")
print(f"验证集标签分布: {Counter(valid_labels.tolist() if isinstance(valid_labels, np.ndarray) else valid_labels)}")
print(f"测试集标签分布: {Counter(test_labels.tolist() if isinstance(test_labels, np.ndarray) else test_labels)}")