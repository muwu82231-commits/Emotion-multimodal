import pandas as pd
import os

# 创建保存文本数据的目录
os.makedirs("./data/text_data", exist_ok=True)

# 读取CSV文件
df = pd.read_csv("./data/label.csv", header=None)
df.columns = ["video_id", "clip_id", "text", "score1", "score2", "score3", "score4", "label", "split"]

# 标签映射：将文本标签转换为数字
label_map = {"Negative": 0, "Neutral": 1, "Positive": 2}

# 按split列拆分数据
train_data = df[df["split"] == "train"]
valid_data = df[df["split"] == "valid"]
test_data = df[df["split"] == "test"]

print(f"训练集样本数：{len(train_data)}")
print(f"验证集样本数：{len(valid_data)}")
print(f"测试集样本数：{len(test_data)}")

# 将标签转换为数字
train_data["numeric_label"] = train_data["label"].map(label_map)
valid_data["numeric_label"] = valid_data["label"].map(label_map)
test_data["numeric_label"] = test_data["label"].map(label_map)

# 写入文本文件函数
def write_text_and_labels_to_txt(file_path, data):
    with open(file_path, 'w', encoding='utf-8') as file:
        for _, row in data.iterrows():
            text = row['text']
            label = row['numeric_label']
            file.write(f"{text}\t{label}\n")

# 创建训练、验证和测试集文件
write_text_and_labels_to_txt('./data/text_data/train.txt', train_data)
write_text_and_labels_to_txt('./data/text_data/valid.txt', valid_data)
write_text_and_labels_to_txt('./data/text_data/test.txt', test_data)

# 统计每个数据集中各类别的数量
def count_labels(data):
    return data["label"].value_counts().to_dict()

print("训练集标签分布:", count_labels(train_data))
print("验证集标签分布:", count_labels(valid_data))
print("测试集标签分布:", count_labels(test_data))

print("数据集创建完成！文件保存在 ./data/text_data/ 目录下")