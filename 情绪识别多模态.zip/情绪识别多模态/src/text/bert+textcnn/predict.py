from model import BertTextModel_last_layer, BertTextModel_encode_layer
from utils import read_data, MyDataset
from torch.utils.data import DataLoader
import torch
from config import parsers
import numpy as np
import matplotlib.pyplot as plt
import os
from sklearn.metrics import accuracy_score
from tqdm import tqdm

def max_iter(true_labels, predicted_labels):
    # 获取类别数量
    num_classes = max(max(true_labels), max(predicted_labels)) + 1

    # 计算混淆矩阵
    confusion_matrix = np.zeros((num_classes, num_classes), dtype=int)
    for true_label, predicted_label in zip(true_labels, predicted_labels):
        confusion_matrix[true_label][predicted_label] += 1

    # 类别标签
    labels = ['0', '1', '2']

    # 绘制混淆矩阵
    fig, ax = plt.subplots()
    im = ax.imshow(confusion_matrix, cmap='Blues')

    # 设置颜色条
    cbar = ax.figure.colorbar(im, ax=ax)

    # 设置标签
    ax.set(xticks=np.arange(num_classes),
        yticks=np.arange(num_classes),
        xticklabels=labels, yticklabels=labels,
        title='Confusion Matrix',
        ylabel='True label',
        xlabel='Predicted label')

    # 在矩阵方格中显示数值
    thresh = confusion_matrix.max() / 2.
    for i in range(num_classes):
        for j in range(num_classes):
            ax.text(j, i, format(confusion_matrix[i, j], 'd'),
                    ha="center", va="center",
                    color="white" if confusion_matrix[i, j] > thresh else "black")

    # 自动调整布局
    fig.tight_layout()
    
    # 确保目录存在
    os.makedirs('output/text/bert+textcnn', exist_ok=True)
    plt.savefig("output/text/bert+textcnn/混淆矩阵.jpg")
    # 显示图形
    plt.close()  # 关闭图形，不显示

def load_model(model_path, device, args):
    if args.select_model_last:
        model = BertTextModel_last_layer().to(device)
    else:
        model = BertTextModel_encode_layer().to(device)
    model.load_state_dict(torch.load(model_path))
    model.eval()
    return model

def test_data():
    args = parsers()
    device = "cuda:0" if torch.cuda.is_available() else "cpu"

    # 加载测试数据
    test_text, test_label = read_data(args.test_file)
    test_dataset = MyDataset(test_text, labels=test_label, with_labels=True)
    test_dataloader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)

    # 确定模型路径
    root, name = os.path.split(args.save_model_best)
    model_path = os.path.join(root, str(args.select_model_last) + "_" + os.path.basename(args.save_model_best))
    
    # 检查模型文件是否存在
    if not os.path.exists(model_path):
        print(f"模型文件不存在: {model_path}")
        print("尝试使用最后保存的模型...")
        root, name = os.path.split(args.save_model_last)
        model_path = os.path.join(root, str(args.select_model_last) + "_" + os.path.basename(args.save_model_last))
        if not os.path.exists(model_path):
            print(f"最后保存的模型也不存在: {model_path}")
            return

    # 加载模型
    model = load_model(model_path, device, args)
    model.eval()

    # 评估模型
    all_pred, all_true = [], []
    with torch.no_grad():
        for batch_con in tqdm(test_dataloader):
            batch_con = tuple(p.to(device) for p in batch_con)
            # 最后一个元素是标签
            batch_inputs = batch_con[:-1]
            batch_label = batch_con[-1]
            
            pred = model(batch_inputs)
            pred = torch.argmax(pred, dim=1)
            
            pred = pred.cpu().numpy().tolist()
            label = batch_label.cpu().numpy().tolist()
            
            all_pred.extend(pred)
            all_true.extend(label)
    
    # 保存测试结果
    os.makedirs('output/text/bert+textcnn', exist_ok=True)
    with open("output/text/bert+textcnn/test_results.txt", "w", encoding="utf-8") as file:
        for item1, item2, item3 in zip(test_text, test_label, all_pred):
            file.write(f"{item1}\t{item2}\t{item3}\n")
    
    # 计算准确率
    accuracy = accuracy_score(all_true, all_pred)
    print(f"test dataset accuracy: {accuracy:.4f}")
    
    # 生成混淆矩阵
    max_iter(all_true, all_pred)
    
    return accuracy

if __name__ == "__main__":
    test_data()
