import os

# 1. 设置环境变量来抑制 TensorFlow C++ 日志 (INFO, WARNING, ERROR)
# '0' (默认): 所有日志
# '1': 过滤 INFO 日志
# '2': 过滤 INFO 和 WARNING 日志
# '3': 过滤 INFO, WARNING, 和 ERROR 日志
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0' # 关闭 oneDNN 的提示信息

import numpy as np
import argparse
import tensorflow as tf
from tensorflow.keras.models import Model as KerasModel
from tensorflow.keras.layers import Input
import librosa

# 2. 设置 TensorFlow Python 端日志级别 (FATAL 会隐藏几乎所有东西)
tf.get_logger().setLevel('FATAL')

# 尝试抑制 absl 日志 (TensorFlow 的依赖库)
try:
    import absl.logging
    absl.logging.set_verbosity(absl.logging.FATAL)
except ImportError:
    pass

from TIMNET import TIMNET
from Model import WeightLayer

CLASS_LABELS_DICT = {
    "CASIA": ("angry", "fear", "happy", "neutral", "sad", "surprise"),
    "EMODB": ("angry", "boredom", "disgust", "fear", "happy", "neutral", "sad"),
    "EMOVO": ("angry", "disgust", "fear", "happy", "neutral", "sad", "surprise"),
    "IEMOCAP": ("angry", "happy", "neutral", "sad"),
    "RAVDE": ("angry", "calm", "disgust", "fear", "happy", "neutral", "sad", "surprise"),
    "SAVEE": ("angry", "disgust", "fear", "happy", "neutral", "sad", "surprise")
}

MEAN_SIGNAL_LENGTH_DICT = {
    "CASIA": 88000,
    "EMODB": 96000,
    "EMOVO": 96000,
    "IEMOCAP": 310000,
    "RAVDE": 110000,
    "SAVEE": 130000
}

def get_mfcc_feature(file_path: str, mean_signal_length: int, n_mfcc: int = 39):
    signal, fs = librosa.load(file_path, sr=None)
    s_len = len(signal)
    if s_len < mean_signal_length:
        pad_len = mean_signal_length - s_len
        pad_rem = pad_len % 2
        pad_len //= 2
        signal = np.pad(signal, (pad_len, pad_len + pad_rem), 'constant', constant_values=0)
    else:
        pad_len = s_len - mean_signal_length
        pad_len //= 2
        signal = signal[pad_len:pad_len + mean_signal_length]
    mfcc = librosa.feature.mfcc(y=signal, sr=fs, n_mfcc=n_mfcc)
    feature = np.transpose(mfcc)
    return feature

def build_prediction_model(args_model, input_shape, num_classes):
    inputs = Input(shape=input_shape)
    multi_decision = TIMNET(nb_filters=args_model.filter_size,
                            kernel_size=args_model.kernel_size,
                            nb_stacks=args_model.stack_size,
                            dilations=args_model.dilation_size,
                            dropout_rate=args_model.dropout,
                            activation=args_model.activation,
                            return_sequences=True,
                            name='TIMNET')(inputs)
    decision = WeightLayer()(multi_decision)
    predictions = tf.keras.layers.Dense(num_classes, activation='softmax')(decision)
    model = KerasModel(inputs=inputs, outputs=predictions)
    return model

def predict_emotion(audio_file_path: str, model_weights_path: str, dataset_name: str, model_args: argparse.Namespace):
    if dataset_name not in CLASS_LABELS_DICT or dataset_name not in MEAN_SIGNAL_LENGTH_DICT:
        # 即使我们想抑制日志，关键错误还是应该打印
        print(f"错误: 数据集 '{dataset_name}' 未定义类别标签或平均信号长度。", file=os.sys.stderr)
        return

    class_labels = CLASS_LABELS_DICT[dataset_name]
    mean_signal_len = MEAN_SIGNAL_LENGTH_DICT[dataset_name]
    num_classes = len(class_labels)
    n_mfcc = 39

    # --- 移除不必要的 print ---
    print(f"正在处理音频文件: {audio_file_path}")
    mfcc_features = get_mfcc_feature(audio_file_path, mean_signal_length=mean_signal_len, n_mfcc=n_mfcc)
    mfcc_features = np.expand_dims(mfcc_features, axis=0)
    input_shape_model = (mfcc_features.shape[1], mfcc_features.shape[2])
    print(f"提取的特征形状: {mfcc_features.shape}")

    if dataset_name == "IEMOCAP" and model_args.dilation_size != 10:
        # print("注意: IEMOCAP 数据集，推荐 dilation_size 为 10。当前值为:", model_args.dilation_size)
        pass # 只是作为例子，这个 print 也可以去掉

    model = build_prediction_model(model_args, input_shape=input_shape_model, num_classes=num_classes)
    print(f"正在加载模型权重: {model_weights_path}")
    model.load_weights(model_weights_path)
    print("模型加载成功。")

    # print("正在进行预测...")
    # 3. 在 predict 时设置 verbose=0 来关闭进度条
    prediction_probabilities = model.predict(mfcc_features, verbose=0)
    
    predicted_class_index = np.argmax(prediction_probabilities, axis=1)[0]
    predicted_emotion = class_labels[predicted_class_index]
    confidence = prediction_probabilities[0][predicted_class_index]

    # --- 只保留这部分输出 ---
    print("--- 预测结果 ---")
    print(f"音频文件: {os.path.basename(audio_file_path)}")
    print(f"预测情感: {predicted_emotion}")
    print(f"置信度: {confidence:.4f}")
    print("所有类别概率:")
    for i, label in enumerate(class_labels):
        print(f"  {label}: {prediction_probabilities[0][i]:.4f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="使用训练好的 TIM-Net 模型预测单个音频的情感。")
    parser.add_argument('--audio_file', type=str, required=True, help="要预测的音频文件路径 (.wav)。")
    parser.add_argument('--model_weights', type=str, required=True, help="训练好的模型权重文件路径 (.hdf5)。")
    parser.add_argument('--dataset_name', type=str, required=True, choices=CLASS_LABELS_DICT.keys(),
                        help="模型训练时使用的数据集名称。")
    parser.add_argument('--filter_size', type=int, default=39, help="TIM-Net 卷积层滤波器数量。")
    parser.add_argument('--kernel_size', type=int, default=2, help="TIM-Net 卷积核大小。")
    parser.add_argument('--stack_size', type=int, default=1, help="TIM-Net TAB 模块堆叠次数。")
    parser.add_argument('--dilation_size', type=int, default=8, help="TIM-Net 最大空洞因子指数。")
    parser.add_argument('--dropout', type=float, default=0.1, help="TIM-Net Dropout 比率。")
    parser.add_argument('--activation', type=str, default='relu', help="TIM-Net 激活函数。")
    parser.add_argument('--gpu', type=str, default='0', help="指定GPU。")

    cli_args = parser.parse_args()

    # GPU 配置可以保留，但其 print 语句应被移除或注释
    # os.environ['CUDA_VISIBLE_DEVICES'] = cli_args.gpu # 这行可以保留
    gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
    if gpus:
        try:
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)
            # print(f"GPU配置成功: {gpus}") # <--- 移除或注释
        except RuntimeError as e:
            # print(f"GPU配置错误: {e}", file=os.sys.stderr) # <--- 移除或注释，除非你想看错误
            pass
    # else:
        # print("未找到GPU，将使用CPU。") # <--- 移除或注释

    if cli_args.dataset_name == "IEMOCAP" and cli_args.dilation_size != 10:
        # print(f"检测到 IEMOCAP 数据集，将 dilation_size 从 {cli_args.dilation_size} 调整为 10。") # <--- 移除或注释
        cli_args.dilation_size = 10

    predict_emotion(
        audio_file_path=cli_args.audio_file,
        model_weights_path=cli_args.model_weights,
        dataset_name=cli_args.dataset_name,
        model_args=cli_args
    )