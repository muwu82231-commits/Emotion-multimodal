import numpy as np
import pickle
import os
from tqdm import tqdm
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold, GridSearchCV, cross_validate
from sklearn.metrics import accuracy_score, classification_report, precision_score, recall_score, f1_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier, GradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier, BaggingClassifier
from sklearn.svm import LinearSVC
from sklearn.ensemble import StackingClassifier
import warnings
import pandas as pd
import seaborn as sns
warnings.filterwarnings("ignore")

# 创建必要的目录
os.makedirs('./src/ML/models', exist_ok=True)
os.makedirs('./src/ML/result', exist_ok=True)
os.makedirs('./src/ML/result/boxplots', exist_ok=True)

# 1. 加载文本特征
print("加载文本特征...")
with open('/home/egdon/workspace/Multimodal-emotion-main/features/text_ml_features.pkl', 'rb') as f:
    features = pickle.load(f)

# 准备数据
train_text = features['train']['text']
train_labels = features['train']['classification_labels_T']
valid_text = features['valid']['text']
valid_labels = features['valid']['classification_labels_T']
test_text = features['test']['text']
test_labels = features['test']['classification_labels_T']

print(f"训练集形状: {train_text.shape}, 标签分布: {np.bincount(train_labels)}")
print(f"验证集形状: {valid_text.shape}, 标签分布: {np.bincount(valid_labels)}")
print(f"测试集形状: {test_text.shape}, 标签分布: {np.bincount(test_labels)}")

# 2. 定义6个模型及其参数网格
models = {
    "DecisionTree": {
        "model": DecisionTreeClassifier(random_state=42),
        "params": {
            "criterion": ["gini", "entropy"],
            "max_depth": [None, 5, 10],
            "min_samples_split": [2, 5]
        }
    },
    "AdaBoost": {
        "model": AdaBoostClassifier(random_state=42,algorithm='SAMME'),
        "params": {
            "n_estimators": [50, 100],
            "learning_rate": [0.1, 1.0]
        }
    },
    "GradientBoostingTree": {
        "model": GradientBoostingClassifier(random_state=42),
        "params": {
            "n_estimators": [50, 100],
            "learning_rate": [0.1, 0.5],
            "max_depth": [3, 5]
        }
    },
    "Bagging": {
        "model": BaggingClassifier(estimator=DecisionTreeClassifier(random_state=42), random_state=42),
        "params": {
            "n_estimators": [10, 50],
            "max_samples": [0.7, 1.0]
        }
    },
    "RandomForest": {
        "model": RandomForestClassifier(random_state=42),
        "params": {
            "n_estimators": [50, 100],
            "max_depth": [None, 10],
            "min_samples_split": [2, 5]
        }
    },
    "LinearSVC": {
        "model": LinearSVC(random_state=42, dual=False),
        "params": {
            "C": [0.1, 1],
            "loss": ["squared_hinge"]
        }
    }
}

# 3. 执行五轮10折交叉验证并选择最佳参数
print("开始五轮10折交叉验证...")
best_models = {}
avg_scores = {}
best_params = {}

# 用于存储每个模型每个指标的所有交叉验证结果
cv_results = {model_name: {
    'accuracy': [], 'precision': [], 'recall': [], 'macro_F1': [], 'micro_F1': []
} for model_name in models.keys()}

for model_name, model_info in models.items():
    print(f"\n{model_name} 模型：")
    round_scores = []
    round_params = []
    
    # 五轮交叉验证
    for round_idx in range(5):
        print(f"  第{round_idx+1}轮")
        
        # 创建10折交叉验证
        kfold = KFold(n_splits=10, shuffle=True, random_state=42+round_idx)
        
        # 用GridSearchCV寻找最佳参数
        grid_search = GridSearchCV(
            estimator=model_info["model"],
            param_grid=model_info["params"],
            cv=kfold,
            scoring="accuracy",
            n_jobs=-1
        )
        
        # 训练模型
        grid_search.fit(train_text, train_labels)
        
        # 记录最佳分数和参数
        round_scores.append(grid_search.best_score_)
        round_params.append(grid_search.best_params_)
        print(f"    最佳交叉验证分数: {grid_search.best_score_:.4f}")
        print(f"    最佳参数: {grid_search.best_params_}")

        # 使用最佳参数设置模型进行交叉验证收集更详细的指标
        best_model = grid_search.best_estimator_
        
        # 定义多个评估指标
        scoring = {'accuracy': 'accuracy',
                  'precision_macro': 'precision_macro',
                  'recall_macro': 'recall_macro',
                  'f1_macro': 'f1_macro',
                  'f1_micro': 'f1_micro'}
        
        # 执行交叉验证并收集多个指标的结果
        cv_scores = cross_validate(best_model, train_text, train_labels, 
                                 cv=kfold, scoring=scoring)
        
        # 存储每一折的指标结果
        cv_results[model_name]['accuracy'].extend(cv_scores['test_accuracy'])
        cv_results[model_name]['precision'].extend(cv_scores['test_precision_macro'])
        cv_results[model_name]['recall'].extend(cv_scores['test_recall_macro'])
        cv_results[model_name]['macro_F1'].extend(cv_scores['test_f1_macro'])
        cv_results[model_name]['micro_F1'].extend(cv_scores['test_f1_micro'])
    
    # 计算平均分数
    avg_score = np.mean(round_scores)
    avg_scores[model_name] = avg_score
    
    # 选择出现最多次的参数配置
    param_count = {}
    for params in round_params:
        param_str = str(params)
        param_count[param_str] = param_count.get(param_str, 0) + 1
    
    best_param_str = max(param_count, key=param_count.get)
    best_param = eval(best_param_str)
    best_params[model_name] = best_param
    
    print(f"  五轮平均分数: {avg_score:.4f}")
    print(f"  选择的最佳参数: {best_param}")
    
    # 使用最佳参数创建最终模型
    if model_name == "DecisionTree":
        best_models[model_name] = DecisionTreeClassifier(random_state=42, **best_param)
    elif model_name == "AdaBoost":
        best_models[model_name] = AdaBoostClassifier(random_state=42, algorithm='SAMME', **best_param)
    elif model_name == "GradientBoostingTree":
        best_models[model_name] = GradientBoostingClassifier(random_state=42, **best_param)
    elif model_name == "Bagging":
        best_models[model_name] = BaggingClassifier(
            estimator=DecisionTreeClassifier(random_state=42),
            random_state=42,
            **best_param
        )
    elif model_name == "RandomForest":
        best_models[model_name] = RandomForestClassifier(random_state=42, **best_param)
    elif model_name == "LinearSVC":
        best_models[model_name] = LinearSVC(random_state=42, dual=False, **best_param)

# 4. 按照平均分数对模型排序
sorted_models = sorted(avg_scores.items(), key=lambda x: x[1], reverse=True)
print("\n模型排名:")
for idx, (model_name, score) in enumerate(sorted_models):
    print(f"{idx+1}. {model_name}: {score:.4f}")

# 5. 选择效果最好的三个模型
top3_models = [model_name for model_name, _ in sorted_models[:3]]
print(f"\n选择的三个最佳模型: {top3_models}")

# 6. 准备Stacking模型
# 文档要求：Stacking模型以SVM、梯度提升树和随机森林为基学习器，决策树为元学习器
estimators = []
for name in ["LinearSVC", "GradientBoostingTree", "RandomForest"]:
    if name in best_models:
        estimators.append((name.lower().replace(" ", "_"), best_models[name]))
    else:
        # 如果某个模型不在最佳模型中，创建一个默认版本
        if name == "LinearSVC":
            estimators.append(("linearsvc", LinearSVC(random_state=42, dual=False)))
        elif name == "GradientBoostingTree":
            estimators.append(("gradientboostingtree", GradientBoostingClassifier(random_state=42)))
        elif name == "RandomForest":
            estimators.append(("randomforest", RandomForestClassifier(random_state=42)))

stacking_model = StackingClassifier(
    estimators=estimators,
    final_estimator=DecisionTreeClassifier(random_state=42),
    cv=5
)

# 7. 训练所选的最佳模型和Stacking模型
final_models = {}
for model_name in top3_models:
    final_models[model_name] = best_models[model_name]
final_models["Stacking"] = stacking_model

print("\n训练和评估最终模型:")
for name, model in final_models.items():
    print(f"\n{name} 模型训练中...")
    
    # 训练模型
    if name == "Stacking":
        # 对于Stacking模型，使用训练和验证集的合并数据
        X_combined = np.vstack([train_text, valid_text])
        y_combined = np.concatenate([train_labels, valid_labels])
        model.fit(X_combined, y_combined)
    else:
        model.fit(train_text, train_labels)
    
    # 在测试集上评估
    test_pred = model.predict(test_text)
    test_acc = accuracy_score(test_labels, test_pred)
    print(f"  测试集准确率: {test_acc:.4f}")
    
    # 详细分类报告
    print("  分类报告:")
    target_names = ['消极', '中性', '积极']
    report = classification_report(test_labels, test_pred, target_names=target_names)
    print(report)
    
    # 保存模型
    with open(f'./src/ML/models/text_{name.lower().replace(" ", "_")}_model.pkl', 'wb') as f:
        pickle.dump(model, f)

# 8. 为Stacking模型收集交叉验证数据
print("\n为Stacking模型收集交叉验证结果...")
# 初始化Stacking模型的交叉验证结果
cv_results["Stacking"] = {
    'accuracy': [], 'precision': [], 'recall': [], 'macro_F1': [], 'micro_F1': []
}

# 合并训练集和验证集以用于交叉验证
X_combined = np.vstack([train_text, valid_text])
y_combined = np.concatenate([train_labels, valid_labels])

# 进行五轮10折交叉验证
for round_idx in range(5):
    print(f"  第{round_idx+1}轮")
    
    # 创建10折交叉验证
    kfold = KFold(n_splits=10, shuffle=True, random_state=42+round_idx)
    
    # 定义评估指标
    scoring = {'accuracy': 'accuracy',
              'precision_macro': 'precision_macro',
              'recall_macro': 'recall_macro',
              'f1_macro': 'f1_macro',
              'f1_micro': 'f1_micro'}
    
    # 执行交叉验证
    cv_scores = cross_validate(stacking_model, X_combined, y_combined, 
                             cv=kfold, scoring=scoring)
    
    # 存储每一折的指标结果
    cv_results["Stacking"]['accuracy'].extend(cv_scores['test_accuracy'])
    cv_results["Stacking"]['precision'].extend(cv_scores['test_precision_macro'])
    cv_results["Stacking"]['recall'].extend(cv_scores['test_recall_macro'])
    cv_results["Stacking"]['macro_F1'].extend(cv_scores['test_f1_macro'])
    cv_results["Stacking"]['micro_F1'].extend(cv_scores['test_f1_micro'])

# 9. 多数投票策略
print("\n实现多数投票策略:")
test_predictions = {}
for name, model in final_models.items():
    test_predictions[name] = model.predict(test_text)

# 进行多数投票
ensemble_pred = np.zeros_like(test_labels)
for i in range(len(test_labels)):
    votes = [test_predictions[name][i] for name in final_models]
    # 计算每个类别的票数
    vote_counts = np.bincount(votes, minlength=3)
    # 取票数最多的类别
    ensemble_pred[i] = np.argmax(vote_counts)

# 评估集成结果
ensemble_acc = accuracy_score(test_labels, ensemble_pred)
print(f"多数投票集成准确率: {ensemble_acc:.4f}")
print("集成分类报告:")
report = classification_report(test_labels, ensemble_pred, target_names=['消极', '中性', '积极'])
print(report)

# 10. 为多数投票策略收集交叉验证数据
print("\n为多数投票策略收集交叉验证结果...")
# 初始化多数投票的交叉验证结果
cv_results["Majority Vote"] = {
    'accuracy': [], 'precision': [], 'recall': [], 'macro_F1': [], 'micro_F1': []
}

# 我们不能直接对多数投票进行交叉验证
# 因此，我们在每个交叉验证折上训练所有基础模型，然后收集它们的投票结果
for round_idx in range(5):
    print(f"  第{round_idx+1}轮")
    
    # 创建10折交叉验证
    kfold = KFold(n_splits=10, shuffle=True, random_state=42+round_idx)
    
    fold_idx = 0
    for train_idx, val_idx in kfold.split(X_combined):
        fold_idx += 1
        # 准备本折的训练和验证数据
        X_train_fold, X_val_fold = X_combined[train_idx], X_combined[val_idx]
        y_train_fold, y_val_fold = y_combined[train_idx], y_combined[val_idx]
        
        # 在本折上训练所有模型
        fold_predictions = []
        for name, model_template in final_models.items():
            if name == "Stacking":
                # 创建一个新的Stacking模型实例
                base_estimators = []
                for est_name, est in estimators:
                    if hasattr(est, "get_params"):
                        # 创建一个新的估计器副本
                        params = est.get_params()
                        if "random_state" in params:
                            params["random_state"] = 42  # 保持随机状态一致
                        if est_name == "linearsvc":
                            new_est = LinearSVC(**params)
                        elif est_name == "gradientboostingtree":
                            new_est = GradientBoostingClassifier(**params)
                        elif est_name == "randomforest":
                            new_est = RandomForestClassifier(**params)
                        base_estimators.append((est_name, new_est))
                
                model = StackingClassifier(
                    estimators=base_estimators,
                    final_estimator=DecisionTreeClassifier(random_state=42),
                    cv=5
                )
            else:
                # 为其他模型创建一个新实例
                model_class = model_template.__class__
                params = model_template.get_params()
                if "random_state" in params:
                    params["random_state"] = 42  # 保持随机状态一致
                model = model_class(**params)
            
            model.fit(X_train_fold, y_train_fold)
            fold_predictions.append(model.predict(X_val_fold))
        
        # 多数投票
        majority_pred = np.zeros_like(y_val_fold)
        for i in range(len(y_val_fold)):
            votes = [pred[i] for pred in fold_predictions]
            vote_counts = np.bincount(votes, minlength=3)
            majority_pred[i] = np.argmax(vote_counts)
        
        # 计算本折的指标
        acc = accuracy_score(y_val_fold, majority_pred)
        prec = precision_score(y_val_fold, majority_pred, average='macro')
        rec = recall_score(y_val_fold, majority_pred, average='macro')
        f1_macro = f1_score(y_val_fold, majority_pred, average='macro')
        f1_micro = f1_score(y_val_fold, majority_pred, average='micro')
        
        # 存储本折的结果
        cv_results["Majority Vote"]['accuracy'].append(acc)
        cv_results["Majority Vote"]['precision'].append(prec)
        cv_results["Majority Vote"]['recall'].append(rec)
        cv_results["Majority Vote"]['macro_F1'].append(f1_macro)
        cv_results["Majority Vote"]['micro_F1'].append(f1_micro)

# 11. 计算所有模型的各项指标
metrics = {
    'accuracy': [],
    'precision': [],
    'recall': [],
    'macro_F1': [],
    'micro_F1': []
}

model_list = list(final_models.keys())
model_list.append("Majority Vote")
all_preds = list(test_predictions.values())
all_preds.append(ensemble_pred)

for i, name in enumerate(model_list):
    preds = all_preds[i]
    
    # 计算各项指标
    metrics['accuracy'].append(accuracy_score(test_labels, preds))
    metrics['precision'].append(precision_score(test_labels, preds, average='macro'))
    metrics['recall'].append(recall_score(test_labels, preds, average='macro'))
    metrics['macro_F1'].append(f1_score(test_labels, preds, average='macro'))
    metrics['micro_F1'].append(f1_score(test_labels, preds, average='micro'))

# 12. 保存交叉验证结果，用于生成箱线图
cv_results_file = './src/ML/result/text_ml_cv_results.pkl'
with open(cv_results_file, 'wb') as f:
    pickle.dump(cv_results, f)

# 13. 将交叉验证结果保存为CSV文件
# 准备CSV数据
csv_data = []
for model_name in cv_results.keys():
    for metric in ['accuracy', 'precision', 'recall', 'macro_F1', 'micro_F1']:
        for value in cv_results[model_name][metric]:
            csv_data.append({
                'Model': model_name,
                'Metric': metric,
                'Value': value
            })

# 创建DataFrame并保存为CSV
cv_df = pd.DataFrame(csv_data)
cv_df.to_csv('./src/ML/result/text_ml_boxplot_data.csv', index=False)

# 14. 保存结果到CSV文件
results_df = pd.DataFrame({
    'Model': model_list,
    'Accuracy': metrics['accuracy'],
    'Precision': metrics['precision'],
    'Recall': metrics['recall'],
    'Macro_F1': metrics['macro_F1'],
    'Micro_F1': metrics['micro_F1']
})
results_df.to_csv('./src/ML/result/text_ml_results.csv', index=False)

print("\nTraining and evaluation completed!")
print("- Models have been saved to ./src/ML/models/ directory")
print("- Results data has been saved to ./src/ML/result/text_ml_results.csv")
print("- Cross-validation results have been saved to ./src/ML/result/text_ml_cv_results.pkl")
print("- Boxplot data has been saved to ./src/ML/result/text_ml_boxplot_data.csv")