import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# 创建保存箱线图的目录
os.makedirs('./src/ML/result/boxplots', exist_ok=True)

# 读取箱线图数据
boxplot_data = pd.read_csv('./src/ML/result/text_ml_boxplot_data.csv')

# 获取所有模型名称的列表
models = boxplot_data['Model'].unique()

# 为每个模型绘制一个箱线图
for model_name in models:
    # 过滤当前模型的数据
    model_data = boxplot_data[boxplot_data['Model'] == model_name]
    
    # 创建图形
    plt.figure(figsize=(10, 6))
    
    # 使用seaborn绘制箱线图
    sns.set_style("whitegrid")
    
    # 自定义箱线图属性
    boxprops = dict(linestyle='-', linewidth=1, color='blue')
    medianprops = dict(linestyle='-', linewidth=1.5, color='red')
    meanprops = dict(marker='D', markeredgecolor='black', markerfacecolor='yellow')
    flierprops = dict(marker='o', markerfacecolor='white', markersize=5, linestyle='none')
    
    # 绘制箱线图
    ax = sns.boxplot(x='Metric', y='Value', data=model_data, 
                    patch_artist=True, boxprops=boxprops, medianprops=medianprops, 
                    showmeans=True, meanprops=meanprops, flierprops=flierprops)
    
    # 设置填充颜色
    for patch in ax.artists:
        patch.set_facecolor('lightblue')
        patch.set_alpha(0.7)
    
    # 计算并显示每个指标的平均值
    for i, metric in enumerate(['accuracy', 'precision', 'recall', 'macro_F1', 'micro_F1']):
        metric_data = model_data[model_data['Metric'] == metric]
        mean_val = metric_data['Value'].mean()
        plt.text(i, mean_val + 0.02, f'{mean_val:.4f}', 
                ha='center', va='bottom', fontsize=9)
    
    # 设置坐标轴和标题
    plt.title(f'Performance Metrics for {model_name}', fontsize=14)
    plt.ylabel('Score', fontsize=12)
    plt.ylim(0, 1)
    
    # 调整x轴标签为更易读的形式
    labels = ['Accuracy', 'Precision', 'Recall', 'Macro F1', 'Micro F1']
    ax.set_xticklabels(labels)
    
    # 保存图像
    plt.tight_layout()
    plt.savefig(f'./src/ML/result/boxplots/{model_name.replace(" ", "_")}_boxplot.png', dpi=300)
    plt.close()

print("所有箱线图已生成完毕，保存在 ./src/ML/result/boxplots/ 目录下")