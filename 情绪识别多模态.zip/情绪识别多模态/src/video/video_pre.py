import cv2
from deepface import DeepFace

def main_custom_loop():
    print("正在启动自定义实时情感检测...")
    print("按 'q' 键退出窗口。")

    # 使用 OpenCV 打开默认摄像头
    cap = cv2.VideoCapture('yanzi.mp4') # 0 代表默认摄像头，也可以是视频文件路径

    if not cap.isOpened():
        print("错误：无法打开摄像头或视频文件。")
        return

    cv2.namedWindow("Real-time Emotion Detection", cv2.WINDOW_NORMAL)

    while True:
        ret, frame = cap.read()
        if not ret:
            print("无法读取视频帧，可能视频已结束。")
            break

        try:
            # 使用 DeepFace.analyze 进行情感分析
            # enforce_detection=False 可以在找不到人脸时不抛出异常
            # detector_backend 可以选择更适合您场景的检测器
            results = DeepFace.analyze(
                img_path=frame,
                actions=['emotion'],
                enforce_detection=False, # 如果希望在没有检测到人脸时不报错
                detector_backend='opencv' # 或者其他检测器，如 'mtcnn', 'retinaface'
            )

            # result 是一个列表，每个元素对应一个检测到的人脸
            for result in results:
                face_region = result['region']
                dominant_emotion = result['dominant_emotion']
                emotion_scores = result['emotion'] # 字典，包含各种情感的得分

                # 在帧上绘制人脸框和情感信息
                x, y, w, h = face_region['x'], face_region['y'], face_region['w'], face_region['h']
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

                # 显示主导情感
                text_to_display = f"Emotion: {dominant_emotion}"
                cv2.putText(frame, text_to_display, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                # （可选）显示更详细的情感得分
                # y_offset = y + h + 20
                # for emotion, score in emotion_scores.items():
                #     cv2.putText(frame, f"{emotion}: {score:.2f}%", (x, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)
                #     y_offset += 15


        except Exception as e:
            # 如果 DeepFace.analyze 在 enforce_detection=True 且未检测到人脸时会抛出异常
            # 或者其他处理错误
            # print(f"分析错误: {e}") # 可以取消注释来调试
            pass # 静默处理错误，继续下一帧

        # 显示处理后的帧
        cv2.imshow("Real-time Emotion Detection", frame)

        # 按 'q' 键退出循环
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # 释放摄像头并关闭所有窗口
    cap.release()
    cv2.destroyAllWindows()
    print("情感检测已停止。")


main_custom_loop()